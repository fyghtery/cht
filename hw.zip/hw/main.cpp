#include "dobby.h"
#include "main.h"
#include "fstream"
using namespace std;

JNIEnv* thread_env;
#define qword long long

struct {
    bool state = 0;
    bool connected = 0;
} GUIBypass;

struct {
    int value = 1;
    bool waitInput = false;
} Speed;
bool AutoBuy1 = 0;

bool camfreeze = false;

bool AFK = 0;

qword libaddr = 0;

struct {
    bool state = 0;
    bool waitInputDelay = 0;
    bool awaitingMoment = 0;
    int delay = 0;
    int spawnMoment = 0;
} Autosend;
struct {
    bool state;
    char* msg = new char[100];
    int delay = 50;
    bool waitinputmsg = 0;
    bool waitinputdelay = 0;
    int last_send = 0;
} Flooder;
unsigned short counter = 0;
qword current_time_ptr = 0;
int current_time = 0;

// ------------------------------ hook methods definition ---------------------------- \\

void (*old_SendOnFootSyncData)(qword a1);
void (*old_CNetGame_Process)();
void (*old_ConnectionSucceeded)(RPCParameters* rpcParams);
void (*old_RequestSpawn)();
void (*old_ChatWindowInputHandler)(const char* input);
char* (*SendChatMessage)(char* msg);
void (*old_OnJsonDataIncoming)(long long* a1, unsigned int guild, const char* json);
void (*AddChatMessage)(char* msg, ...);
void (*old_DialogBoxRPC)(RPCParameters* rpcParams);
void (*SendJsonData)(JNIEnv*, jclass, jint, jbyteArray);
void (*old_StopCamera)();
qword (*FindPlayerPed)();

// ------------------------------ ************************ ---------------------------- \\


void ConnectionSucceeded(RPCParameters* rpcParams){
    if(GUIBypass.state){
        GUIBypass.connected = true;
    }
    old_ConnectionSucceeded(rpcParams);
}
void CNetGame_Process(){
    *(float *)(libaddr + 0x4818DC0) = Speed.value;
    if(Flooder.state) {
        if (!Flooder.waitinputdelay && !Flooder.waitinputmsg) {
            if(current_time < Flooder.last_send + Flooder.delay) {
                Flooder.last_send = current_time;
                SendChatMessage(Flooder.msg);
            }
        }
    }

    current_time = *(int *)current_time_ptr;
    if(Autosend.state && Autosend.waitInputDelay && Autosend.awaitingMoment){
        if(Autosend.spawnMoment + Autosend.delay <= current_time){
            SendChatMessage(OBFUSCATE("/buyhouse"));
            Autosend.state = false;
            Autosend.waitInputDelay = false;
            Autosend.awaitingMoment = false;
        }
    }
    old_CNetGame_Process();
}
void DialogBoxRPC(RPCParameters* rpcParams){
    if(AutoBuy1) {
        char *js = OBFUSCATE("{\"r\":1,\"i\":\"Тип:\",\"l\":0}");
        jsize length = strlen(js);
        jbyteArray byteArray = (thread_env)->NewByteArray(length);
        (thread_env)->SetByteArrayRegion(byteArray, 0, length, (const jbyte *) js);
        return SendJsonData(thread_env, 0, 10, byteArray);
    }
    else {
        old_DialogBoxRPC(rpcParams);
    }
}
void OnJsonDataIncoming(long long* a1, unsigned int guild, const char* json){
    if(guild == 50){
        if(GUIBypass.state) {
            char *js = OBFUSCATE("{\"t\":2}");
            jsize length = strlen(js);
            jbyteArray byteArray = (thread_env)->NewByteArray(length);
            (thread_env)->SetByteArrayRegion(byteArray, 0, length, (const jbyte *) js);
            return SendJsonData(thread_env, 0, 50, byteArray);
        }
    }
    old_OnJsonDataIncoming(a1, guild, json);
}

void StopCamera(){
    if(camfreeze){
        return;
    } else {
        old_StopCamera();
    }
}
void ChatWindowInputHandler(const char* input) {
    if(!strcmp(input, OBFUSCATE("/speed"))){
        AddChatMessage(OBFUSCATE("{ffffff} Input speed value"));
        Speed.waitInput = true;
        return;
    }
    if(Speed.waitInput) {
        Speed.value = atoi(input);
        AddChatMessage(OBFUSCATE("{ffffff}New speed value: %d"), Speed.value);
        Speed.waitInput = false;
        return;
    }
    if(!strcmp(input, OBFUSCATE("/camfz"))){
        camfreeze = !camfreeze;
        if(camfreeze) {
            AddChatMessage(OBFUSCATE("{ffffff}Freeze Camera: {39eb15} ON"));
        } else {
            AddChatMessage(OBFUSCATE("{ffffff}Freeze Camera: {850d1b} OFF"));
        }
        return;
    }
    if(!strcmp(input, OBFUSCATE("/afk"))){
        AFK = !AFK;
        if(AFK) {
            AddChatMessage(OBFUSCATE("{ffffff}AFK Ghost: {39eb15} ON"));
        } else {
            AddChatMessage(OBFUSCATE("{ffffff}AFK Ghost: {850d1b} OFF"));
        }
        return;
    }
    if(!strcmp(input, OBFUSCATE("/bypass"))){
        GUIBypass.state = !GUIBypass.state;
        if(GUIBypass.state) {
            AddChatMessage(OBFUSCATE("{ffffff}Spawn bypass: {39eb15} ON"));
        } else {
            AddChatMessage(OBFUSCATE("{ffffff}Spawn bypass: {850d1b} OFF"));
        }
        return;
    }
    if(Flooder.waitinputmsg) {
        Flooder.msg = (char*)input;
        Flooder.waitinputdelay = true;
        Flooder.waitinputmsg = false;
        AddChatMessage(OBFUSCATE("{ffffff} input delay in the chat"));
    }
    if(Flooder.waitinputdelay) {
        Flooder.delay = atoi(input);
        Flooder.waitinputdelay = false;
    }
    if(!strcmp(input, OBFUSCATE("/flooder"))){
        Flooder.state = !Flooder.state;
        if(Flooder.state){
            AddChatMessage(OBFUSCATE("{ffffff}Flooder: {39eb15} ON. {ffffff} input message"));
            Flooder.waitinputmsg = true;
        } else  {
            AddChatMessage(OBFUSCATE("{ffffff}Flooder: {850d1b} OFF"));
            Flooder.waitinputdelay = false;
            Flooder.waitinputmsg = false;
        }
        return;
    }
    if(!strcmp(input, OBFUSCATE("/abuy"))){
        AutoBuy1 = !AutoBuy1;
        if(AutoBuy1){
            AddChatMessage(OBFUSCATE("{ffffff}Autobuy: {39eb15} ON"));
        } else  {
            AddChatMessage(OBFUSCATE("{ffffff}Autobuy: {850d1b} OFF"));
        }
        return;
    }
    if(Autosend.waitInputDelay){
        Autosend.delay = atoi(input);
        Autosend.waitInputDelay = false;
        return;
    }
    if(!strcmp(input, OBFUSCATE("/as"))){
        if(Autosend.state){
            AddChatMessage(OBFUSCATE("{ffffff}Autosend: {850d1b} OFF"));
        } else  {
            AddChatMessage(OBFUSCATE("{ffffff}Autosend: {39eb15} ON. {ffffff} Input integer delay"));
            Autosend.waitInputDelay = true;
        }
        Autosend.state = !Autosend.state;
        return;
    }
    old_ChatWindowInputHandler(input);
}
void SendOnFootSyncData(qword a1){

    if(AFK) { return; } else {

        old_SendOnFootSyncData(a1);

    }
}

void RequestSpawn(){
    if(Autosend.state){
        Autosend.spawnMoment = current_time;
        Autosend.awaitingMoment = true;
    }
    old_RequestSpawn();
}
void hook(){

    void* libraryPointer = dlsym(dlopen(OBFUSCATE("libblackrussia-client.so"), 4), OBFUSCATE("Java_com_blackhub_bronline_game_core_JNILib_multiTouchEvent"));



    qword touchAddress = string2Offset(OBFUSCATE("0x5D1E1C"));
    libaddr =  ((qword)libraryPointer - touchAddress);

    qword addchatmessage = ((qword)libaddr + string2Offset(OBFUSCATE("0x567780")));
    qword cjson_sendjsondata = ((qword)libaddr + string2Offset(OBFUSCATE("0x5CA898")));
    qword dialogbox_rpc = ((qword)libaddr + string2Offset(OBFUSCATE("0x4FD678")));
    qword onjsondataincoming = ((qword)libaddr + string2Offset(OBFUSCATE("0x5CAC4C")));
    qword chathandler = ((qword)libaddr + string2Offset(OBFUSCATE("0x57EEEC")));
    qword sendmessage = ((qword)libaddr + string2Offset(OBFUSCATE("0x4C7CAC")));
    qword requestspawn = ((qword)libaddr + string2Offset(OBFUSCATE("0x4F53BC")));
    qword connectionsucceeded = ((qword)libaddr + string2Offset(OBFUSCATE("0x4AB5D4")));
    qword cnetgame_process = ((qword)libaddr + string2Offset(OBFUSCATE("0x4A9758")));
    qword findplayerped = ((qword)libaddr + string2Offset(OBFUSCATE("0x39B328")));
    qword stopcamera = ((qword)libaddr + string2Offset(OBFUSCATE("0x34BC64")));
    current_time_ptr = ((qword)libaddr + string2Offset(OBFUSCATE("0x4818DB0")));
    qword onfootsyncsend = ((qword)libaddr + string2Offset(OBFUSCATE("0x4A556C")));
    FindPlayerPed = (qword(*)())(findplayerped);


    SendChatMessage = (char*(*)(char*))(sendmessage);

    SendJsonData = (void(*)(JNIEnv*, jclass, jint, jbyteArray))(cjson_sendjsondata);

    AddChatMessage = (void(*)(char*,...))(addchatmessage);

    DobbyHook((void *)stopcamera, (void *) StopCamera, (void **)&old_StopCamera);

    DobbyHook((void *)onfootsyncsend, (void *) SendOnFootSyncData, (void **)&old_SendOnFootSyncData);

    DobbyHook((void *)cnetgame_process, (void *) CNetGame_Process, (void **)&old_CNetGame_Process);

    DobbyHook((void *)connectionsucceeded, (void *) ConnectionSucceeded, (void **)&old_ConnectionSucceeded);

    DobbyHook((void *)chathandler, (void *) ChatWindowInputHandler, (void **)&old_ChatWindowInputHandler);

    DobbyHook((void *)requestspawn, (void *) RequestSpawn, (void **)&old_RequestSpawn);

    DobbyHook((void *)onjsondataincoming, (void *) OnJsonDataIncoming, (void **)&old_OnJsonDataIncoming);

    DobbyHook((void *)dialogbox_rpc, (void *) DialogBoxRPC, (void **)&old_DialogBoxRPC);

}
extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void* reserved) {
    vm->GetEnv((void **) &thread_env, JNI_VERSION_1_6);
    hook();
    return JNI_VERSION_1_6;
}