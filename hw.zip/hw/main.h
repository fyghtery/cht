#pragma once
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <cstdlib>

// Типы, которые требует твой код
struct RPCParameters {
    unsigned char* packet;
    unsigned int bitStream;
};

// Простая функция для конвертации шестнадцатеричных строк в адреса
unsigned long string2Offset(const char* offset) {
    return strtoul(offset, NULL, 16);
}

// Заглушка для функции OBFUSCATE (если нет библиотеки шифрования, просто верни строку)
#define OBFUSCATE(x) x
