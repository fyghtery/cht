LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := modmenu
LOCAL_SRC_FILES := main.cpp
# Указываем, что заголовочные файлы лежат в текущей папке
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_LDLIBS := -llog -landroid
include $(BUILD_SHARED_LIBRARY)

